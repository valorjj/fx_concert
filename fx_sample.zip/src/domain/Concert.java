package domain;

public class Concert {

}
