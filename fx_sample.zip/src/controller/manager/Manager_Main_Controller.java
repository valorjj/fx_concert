package controller.manager;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class Manager_Main_Controller implements Initializable{

	// 1. 매니저 메인 화면
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	}

}
